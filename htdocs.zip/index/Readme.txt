Instalacion y creacion por Express Node

1) Click derecho en carpeta htdocs o raiz del servidor y abrir caja de comandos o Powershell
2) Caja de comandos digitar node "node app" y iniciaria el servidor con los puertos 8888
3) localhost:8888 y mostrara el index.html con los scripts cargados.